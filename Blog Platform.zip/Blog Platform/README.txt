# InkSpace – Blog Platform

InkSpace is a full-stack blogging platform where users can register, log in securely, create and manage blog posts, and interact through comments.

## Features

* User registration and login
* JWT-based authentication
* Create blog posts
* View all blog posts
* View individual posts
* Edit and delete own posts
* Add comments
* View comments
* MySQL database integration
* RESTful backend APIs
* Responsive blogging interface

## Tech Stack

### Frontend

* HTML
* CSS
* JavaScript

### Backend

* Node.js
* Express.js
* JWT
* bcryptjs

### Database

* MySQL

## Project Structure

```text
InkSpace/
├── frontend/
│   └── try.html
│
├── backend/
│   ├── config/
│   │   └── database.js
│   ├── controllers/
│   │   ├── authController.js
│   │   ├── commentController.js
│   │   └── postController.js
│   ├── middleware/
│   │   └── authMiddleware.js
│   ├── routes/
│   │   ├── authRoutes.js
│   │   ├── commentRoutes.js
│   │   └── postRoutes.js
│   ├── .env
│   ├── .gitignore
│   ├── package.json
│   ├── schema.sql
│   └── server.js
│
└── README.md
```

## How to Run

### Backend

Open a terminal inside the backend folder:

```bash
npm install
node server.js
```

The backend runs on:

```text
http://localhost:5000
```

### Database

Create the `inkspace` database in MySQL and execute the SQL schema provided in `schema.sql`.

Configure the database credentials and JWT secret in `.env`.

### Frontend

Open `frontend/try.html` in a browser while the backend server is running.

## API Modules

### Authentication

* `POST /api/auth/register`
* `POST /api/auth/login`
* `GET /api/auth/me`

### Posts

* `GET /api/posts`
* `GET /api/posts/:id`
* `POST /api/posts`
* `PUT /api/posts/:id`
* `DELETE /api/posts/:id`

### Comments

* `POST /api/comments`
* `GET /api/comments/post/:postId`
* `PUT /api/comments/:id`
* `DELETE /api/comments/:id`

## Project Outcome

InkSpace demonstrates full-stack development using a RESTful backend, MySQL database integration, authentication, content management, and user interaction through comments.
