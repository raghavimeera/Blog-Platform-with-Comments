const pool = require('../config/database');

// GET COMMENTS FOR A POST
exports.getCommentsByPostId = async (req, res) => {
    try {
        const { postId } = req.params;

        const [comments] = await pool.query(`
            SELECT 
                c.id, c.post_id, c.comment, c.created_at, c.updated_at,
                u.id AS author_id, u.name AS author_name
            FROM comments c
            JOIN users u ON c.user_id = u.id
            WHERE c.post_id = ?
            ORDER BY c.created_at DESC
        `, [postId]);

        return res.status(200).json({
            success: true,
            count: comments.length,
            comments
        });
    } catch (error) {
        console.error('Get Comments Error:', error);
        return res.status(500).json({
            success: false,
            message: 'Server error retrieving comments.'
        });
    }
};

// CREATE COMMENT
exports.createComment = async (req, res) => {
    try {
        const { post_id, comment } = req.body;
        const userId = req.user.id;

        if (!post_id || !comment || !comment.trim()) {
            return res.status(400).json({
                success: false,
                message: 'Post ID and comment content are required.'
            });
        }

        const [posts] = await pool.query('SELECT id FROM posts WHERE id = ?', [post_id]);
        if (posts.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'Target post does not exist.'
            });
        }

        const [result] = await pool.query(
            'INSERT INTO comments (post_id, user_id, comment) VALUES (?, ?, ?)',
            [post_id, userId, comment.trim()]
        );

        const [newComment] = await pool.query(`
            SELECT 
                c.id, c.post_id, c.comment, c.created_at,
                u.id AS author_id, u.name AS author_name
            FROM comments c
            JOIN users u ON c.user_id = u.id
            WHERE c.id = ?
        `, [result.insertId]);

        return res.status(201).json({
            success: true,
            message: 'Comment added successfully.',
            comment: newComment[0]
        });
    } catch (error) {
        console.error('Create Comment Error:', error);
        return res.status(500).json({
            success: false,
            message: 'Server error creating comment.'
        });
    }
};

// UPDATE COMMENT (Owner only)
exports.updateComment = async (req, res) => {
    try {
        const commentId = req.params.id;
        const userId = req.user.id;
        const { comment } = req.body;

        if (!comment || !comment.trim()) {
            return res.status(400).json({
                success: false,
                message: 'Updated comment text is required.'
            });
        }

        const [existing] = await pool.query('SELECT user_id FROM comments WHERE id = ?', [commentId]);

        if (existing.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'Comment not found.'
            });
        }

        if (existing[0].user_id !== userId) {
            return res.status(403).json({
                success: false,
                message: 'Unauthorized. You can only edit your own comment.'
            });
        }

        await pool.query('UPDATE comments SET comment = ? WHERE id = ?', [comment.trim(), commentId]);

        return res.status(200).json({
            success: true,
            message: 'Comment updated successfully.'
        });
    } catch (error) {
        console.error('Update Comment Error:', error);
        return res.status(500).json({
            success: false,
            message: 'Server error updating comment.'
        });
    }
};

// DELETE COMMENT (Owner only)
exports.deleteComment = async (req, res) => {
    try {
        const commentId = req.params.id;
        const userId = req.user.id;

        const [existing] = await pool.query('SELECT user_id FROM comments WHERE id = ?', [commentId]);

        if (existing.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'Comment not found.'
            });
        }

        if (existing[0].user_id !== userId) {
            return res.status(403).json({
                success: false,
                message: 'Unauthorized. You can only delete your own comment.'
            });
        }

        await pool.query('DELETE FROM comments WHERE id = ?', [commentId]);

        return res.status(200).json({
            success: true,
            message: 'Comment deleted successfully.'
        });
    } catch (error) {
        console.error('Delete Comment Error:', error);
        return res.status(500).json({
            success: false,
            message: 'Server error deleting comment.'
        });
    }
};