const pool = require('../config/database');

// GET ALL POSTS (With optional search and category filters)
exports.getAllPosts = async (req, res) => {
    try {
        const { search, category } = req.query;

        let query = `
            SELECT 
                p.id, p.user_id, p.title, p.subtitle, p.content, p.cover_image, p.category, p.created_at, p.updated_at,
                u.name AS author_name,
                COUNT(c.id) AS comment_count
            FROM posts p
            JOIN users u ON p.user_id = u.id
            LEFT JOIN comments c ON p.id = c.post_id
        `;

        const queryParams = [];
        const whereClauses = [];

        if (search) {
            whereClauses.push('(p.title LIKE ? OR p.content LIKE ? OR p.subtitle LIKE ?)');
            const searchParam = `%${search}%`;
            queryParams.push(searchParam, searchParam, searchParam);
        }

        if (category) {
            whereClauses.push('p.category = ?');
            queryParams.push(category);
        }

        if (whereClauses.length > 0) {
            query += ' WHERE ' + whereClauses.join(' AND ');
        }

        query += ' GROUP BY p.id ORDER BY p.created_at DESC';

        const [posts] = await pool.query(query, queryParams);

        return res.status(200).json({
            success: true,
            count: posts.length,
            posts
        });
    } catch (error) {
        console.error('Get All Posts Error:', error);
        return res.status(500).json({
            success: false,
            message: 'Server error retrieving posts.'
        });
    }
};

// GET SINGLE POST WITH AUTHOR & COMMENTS
exports.getPostById = async (req, res) => {
    try {
        const postId = req.params.id;

        const [posts] = await pool.query(`
            SELECT 
                p.id, p.user_id, p.title, p.subtitle, p.content, p.cover_image, p.category, p.created_at, p.updated_at,
                u.name AS author_name, u.email AS author_email
            FROM posts p
            JOIN users u ON p.user_id = u.id
            WHERE p.id = ?
        `, [postId]);

        if (posts.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'Post not found.'
            });
        }

        const [comments] = await pool.query(`
            SELECT 
                c.id, c.comment, c.created_at, c.updated_at,
                u.id AS user_id, u.name AS author_name
            FROM comments c
            JOIN users u ON c.user_id = u.id
            WHERE c.post_id = ?
            ORDER BY c.created_at DESC
        `, [postId]);

        const post = posts[0];

        return res.status(200).json({
            success: true,
            post: {
                ...post,
                comments,
                comment_count: comments.length
            }
        });
    } catch (error) {
        console.error('Get Single Post Error:', error);
        return res.status(500).json({
            success: false,
            message: 'Server error retrieving post.'
        });
    }
};

// CREATE NEW POST
exports.createPost = async (req, res) => {
    try {
        const { title, subtitle, content, cover_image, category } = req.body;
        const userId = req.user.id;

        if (!title || !content) {
            return res.status(400).json({
                success: false,
                message: 'Title and content are required.'
            });
        }

        const [result] = await pool.query(
            'INSERT INTO posts (user_id, title, subtitle, content, cover_image, category) VALUES (?, ?, ?, ?, ?, ?)',
            [userId, title, subtitle || null, content, cover_image || null, category || 'General']
        );

        const [newPost] = await pool.query('SELECT * FROM posts WHERE id = ?', [result.insertId]);

        return res.status(201).json({
            success: true,
            message: 'Post created successfully.',
            post: newPost[0]
        });
    } catch (error) {
        console.error('Create Post Error:', error);
        return res.status(500).json({
            success: false,
            message: 'Server error creating post.'
        });
    }
};

// UPDATE POST (Owner only)
exports.updatePost = async (req, res) => {
    try {
        const postId = req.params.id;
        const userId = req.user.id;
        const { title, subtitle, content, cover_image, category } = req.body;

        const [posts] = await pool.query('SELECT user_id FROM posts WHERE id = ?', [postId]);

        if (posts.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'Post not found.'
            });
        }

        if (posts[0].user_id !== userId) {
            return res.status(403).json({
                success: false,
                message: 'Unauthorized. You can only edit your own posts.'
            });
        }

        await pool.query(
            `UPDATE posts SET 
                title = COALESCE(?, title),
                subtitle = COALESCE(?, subtitle),
                content = COALESCE(?, content),
                cover_image = COALESCE(?, cover_image),
                category = COALESCE(?, category)
            WHERE id = ?`,
            [title, subtitle, content, cover_image, category, postId]
        );

        const [updatedPost] = await pool.query('SELECT * FROM posts WHERE id = ?', [postId]);

        return res.status(200).json({
            success: true,
            message: 'Post updated successfully.',
            post: updatedPost[0]
        });
    } catch (error) {
        console.error('Update Post Error:', error);
        return res.status(500).json({
            success: false,
            message: 'Server error updating post.'
        });
    }
};

// DELETE POST (Owner only)
exports.deletePost = async (req, res) => {
    try {
        const postId = req.params.id;
        const userId = req.user.id;

        const [posts] = await pool.query('SELECT user_id FROM posts WHERE id = ?', [postId]);

        if (posts.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'Post not found.'
            });
        }

        if (posts[0].user_id !== userId) {
            return res.status(403).json({
                success: false,
                message: 'Unauthorized. You can only delete your own posts.'
            });
        }

        await pool.query('DELETE FROM posts WHERE id = ?', [postId]);

        return res.status(200).json({
            success: true,
            message: 'Post deleted successfully.'
        });
    } catch (error) {
        console.error('Delete Post Error:', error);
        return res.status(500).json({
            success: false,
            message: 'Server error deleting post.'
        });
    }
};